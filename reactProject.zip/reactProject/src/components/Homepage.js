import React from "react";
import image from "../images/banner.png"

const Homepage=()=>{
    return(
        <div className="homePage container main">
            <img width="100%" src={image} alt="image" />            
        </div>
    );
};

export default Homepage;